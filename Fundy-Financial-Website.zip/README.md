# Fundy Financial

Fundy Financial is a financial consultation service helping individuals and small businesses make smarter financial decisions.

## Services
- Financial consultations
- Budget planning
- Debt management
- Investment guidance
- Business financial advice

Built for growth.
